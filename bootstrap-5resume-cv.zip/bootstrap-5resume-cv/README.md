# Bootstrap 5 - Resume (CV)

A Pen created on CodePen.io. Original URL: [https://codepen.io/vmoratog/pen/xxRMrXE](https://codepen.io/vmoratog/pen/xxRMrXE).

